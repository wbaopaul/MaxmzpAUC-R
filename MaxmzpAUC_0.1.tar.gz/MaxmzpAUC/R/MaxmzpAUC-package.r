#' MaxmzpAUC.
#'
#' @name MaxmzpAUC
#' @docType package
NULL
